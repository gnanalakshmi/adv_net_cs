﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(casestudy001.Startup))]
namespace casestudy001
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
